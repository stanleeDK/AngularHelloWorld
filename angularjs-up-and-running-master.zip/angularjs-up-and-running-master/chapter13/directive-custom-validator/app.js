// File: chapter13/directive-custom-validator/app.js

angular.module('stockMarketApp', [])
  .controller('MainCtrl', [function() {
    this.zip = '';
  }]);
